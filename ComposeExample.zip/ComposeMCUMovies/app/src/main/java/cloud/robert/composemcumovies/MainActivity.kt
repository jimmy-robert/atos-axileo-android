package cloud.robert.composemcumovies

import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.GridCells
import androidx.compose.foundation.lazy.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.material.Card
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.LiveData
import androidx.lifecycle.liveData
import cloud.robert.composemcumovies.ui.theme.ComposeMcuMoviesTheme
import com.google.accompanist.coil.rememberCoilPainter

class MainActivity : ComponentActivity() {
    private val data = liveData {
        emit(movies)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ComposeMcuMoviesTheme {
                // A surface container using the 'background' color from the theme
                Surface(color = MaterialTheme.colors.background) {
                    Greeting(data)
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Greeting(data: LiveData<List<Movie>>) {
    val items = data.observeAsState(initial = emptyList())
    LazyVerticalGrid(
        cells = GridCells.Fixed(2),
        contentPadding = PaddingValues(4.dp),
    ) {
        items(items.value) { movie ->
            Card(
                modifier = Modifier
                    .padding(4.dp),
                backgroundColor = Color.White
            ) {
                Column {
                    Image(
                        painter = rememberCoilPainter(request = "https://image.tmdb.org/t/p/w500${movie.posterPath}"),
                        contentDescription = "Image",
                        modifier = Modifier.aspectRatio(2 / 3f)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = movie.releaseDate.take(4),
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = movie.title,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    AndroidView(
                        modifier = Modifier
                            .fillParentMaxWidth()
                            .height(50.dp),
                        factory = { context ->
                            View(context).apply {
                                layoutParams = ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                )
                                setBackgroundColor(android.graphics.Color.RED)
                            }
                        }
                    )
                }
            }
        }
    }
}

/*@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    ComposeMcuMoviesTheme {
        Greeting("")
    }
}

@Preview(showBackground = true, widthDp = 400)
@Composable
fun DefaultPreview2() {
    ComposeMcuMoviesTheme {
        Greeting("Android again")
    }
}*/

data class Movie(
    val id: Int,
    val genres: List<String>,
    val title: String,
    val releaseDate: String,
    val overview: String,
    val tagline: String,
    val posterPath: String,
    val backdropPath: String,
    val vote: Double,
    val actors: List<Int> = emptyList()
)

val movies = listOf(
    Movie(
        id = 1726,
        genres = listOf(
            "Action",
            "Science Fiction",
            "Adventure"
        ),
        title = "Iron Man",
        releaseDate = "2008-04-30",
        overview = "After being held captive in an Afghan cave, billionaire engineer Tony Stark creates a unique weaponized suit of armor to fight evil.",
        tagline = "Heroes aren't born. They're built.",
        posterPath = "/78lPtwv72eTNqFW9COBYI0dWDJa.jpg",
        backdropPath = "/vbY95t58MDArtyUXUIb8Fx1dCry.jpg",
        vote = 7.6,
        actors = listOf(
            3223,
            12052,
            15277,
            2231
        )
    ),
    Movie(
        id = 10138,
        genres = listOf(
            "Adventure",
            "Action",
            "Science Fiction"
        ),
        title = "Iron Man 2",
        releaseDate = "2010-04-28",
        overview = "With the world now aware of his dual life as the armored superhero Iron Man, billionaire inventor Tony Stark faces pressure from the government, the press and the public to share his technology with the military. Unwilling to let go of his invention, Stark, with Pepper Potts and James 'Rhodey' Rhodes at his side, must forge new alliances – and confront powerful enemies.",
        tagline = "It's not the armor that makes the hero, but the man inside.",
        posterPath = "/6WBeq4fCfn7AN0o21W9qNcRF2l9.jpg",
        backdropPath = "/hCVQPB77eXBGh9abVdrWtKpKgkN.jpg",
        vote = 6.8,
        actors = listOf(
            3223,
            12052,
            1896,
            1245,
            2231,
            21134,
            15277
        )
    ),
    Movie(
        id = 68721,
        genres = listOf(
            "Action",
            "Adventure",
            "Science Fiction"
        ),
        title = "Iron Man 3",
        releaseDate = "2013-04-18",
        overview = "When Tony Stark's world is torn apart by a formidable terrorist called the Mandarin, he starts an odyssey of rebuilding and retribution.",
        tagline = "Unleash the power behind the armor.",
        posterPath = "/qhPtAc1TKbMPqNvcdXSOn9Bn7hZ.jpg",
        backdropPath = "/4TSqtluelcWByj8YZdqwzQVjI0O.jpg",
        vote = 6.9,
        actors = listOf(
            3223,
            12052,
            1896,
            15277,
            103
        )
    ),
    Movie(
        id = 1724,
        genres = listOf(
            "Science Fiction",
            "Action",
            "Adventure"
        ),
        title = "The Incredible Hulk",
        releaseDate = "2008-06-12",
        overview = "Scientist Bruce Banner scours the planet for an antidote to the unbridled force of rage within him: the Hulk. But when the military masterminds who dream of exploiting his powers force him back to civilization, he finds himself coming face to face with a new, deadly foe.",
        tagline = "You'll like him when he's angry.",
        posterPath = "/odVVJrCOveHXCBc5Pf2k4XmOhIz.jpg",
        backdropPath = "/xfBnQ4mgf1jYZsscJGJjr6ce0Ar.jpg",
        vote = 6.2,
        actors = listOf(
            227,
            3223
        )
    ),
    Movie(
        id = 10195,
        genres = listOf(
            "Adventure",
            "Fantasy",
            "Action"
        ),
        title = "Thor",
        releaseDate = "2011-04-21",
        overview = "Against his father Odin's will, The Mighty Thor - a powerful but arrogant warrior god - recklessly reignites an ancient war. Thor is cast down to Earth and forced to live among humans as punishment. Once here, Thor learns what it takes to be a true hero when the most dangerous villain of his world sends the darkest forces of Asgard to invade Earth.",
        tagline = "Two worlds. One hero.",
        posterPath = "/prSfAi1xGrhLQNxVSUFh61xQ4Qy.jpg",
        backdropPath = "/cDJ61O1STtbWNBwefuqVrRe3d7l.jpg",
        vote = 6.8,
        actors = listOf(
            74568,
            524,
            91606,
            14343,
            17604,
            2231
        )
    ),
    Movie(
        id = 76338,
        genres = listOf(
            "Action",
            "Adventure",
            "Fantasy"
        ),
        title = "Thor: The Dark World",
        releaseDate = "2013-10-29",
        overview = "Thor fights to restore order across the cosmos… but an ancient race led by the vengeful Malekith returns to plunge the universe back into darkness. Faced with an enemy that even Odin and Asgard cannot withstand, Thor must embark on his most perilous and personal journey yet, one that will reunite him with Jane Foster and force him to sacrifice everything to save us all.",
        tagline = "Delve into the darkness",
        posterPath = "/wp6OxE4poJ4G7c0U2ZIXasTSMR7.jpg",
        backdropPath = "/uhYoytlNaq46dG81wLmHqaSuzWu.jpg",
        vote = 6.6,
        actors = listOf(
            74568,
            524,
            91606,
            14343,
            16828
        )
    ),
    Movie(
        id = 284053,
        genres = listOf(
            "Action",
            "Adventure",
            "Comedy",
            "Fantasy",
            "Science Fiction"
        ),
        title = "Thor: Ragnarok",
        releaseDate = "2017-10-25",
        overview = "Thor is imprisoned on the other side of the universe and finds himself in a race against time to get back to Asgard to stop Ragnarok, the destruction of his home-world and the end of Asgardian civilization, at the hands of a powerful new threat, the ruthless Hela.",
        tagline = "No Hammer. No Problem.",
        posterPath = "/rzRwTcFvttcN1ZpX2xv4j3tSdJu.jpg",
        backdropPath = "/kaIfm5ryEOwYg8mLbq8HkPuM1Fo.jpg",
        vote = 7.6,
        actors = listOf(
            74568,
            91606,
            62561,
            103,
            71580,
            55934,
            1245
        )
    ),
    Movie(
        id = 1771,
        genres = listOf(
            "Action",
            "Adventure",
            "Science Fiction"
        ),
        title = "Captain America: The First Avenger",
        releaseDate = "2011-07-22",
        overview = "During World War II, Steve Rogers is a sickly man from Brooklyn who's transformed into super-soldier Captain America to aid in the war effort. Rogers must stop the Red Skull – Adolf Hitler's ruthless head of weaponry, and the leader of an organization that intends to use a mysterious device of untold powers for world domination.",
        tagline = "When patriots become heroes",
        posterPath = "/vSNxAJTlD0r02V9sPYpOjqDZXUK.jpg",
        backdropPath = "/yFuKvT4Vm3sKHdFY4eG6I4ldAnn.jpg",
        vote = 7.0,
        actors = listOf(
            16828,
            39459,
            60898,
            2231
        )
    ),
    Movie(
        id = 100402,
        genres = listOf(
            "Action",
            "Adventure",
            "Science Fiction"
        ),
        title = "Captain America: The Winter Soldier",
        releaseDate = "2014-03-20",
        overview = "After the cataclysmic events in New York with The Avengers, Steve Rogers, aka Captain America is living quietly in Washington, D.C. and trying to adjust to the modern world. But when a S.H.I.E.L.D. colleague comes under attack, Steve becomes embroiled in a web of intrigue that threatens to put the world at risk. Joining forces with the Black Widow, Captain America struggles to expose the ever-widening conspiracy while fighting off professional assassins sent to silence him at every turn. When the full scope of the villainous plot is revealed, Captain America and the Black Widow enlist the help of a new ally, the Falcon. However, they soon find themselves up against an unexpected and formidable enemy—the Winter Soldier.",
        tagline = "In heroes we trust.",
        posterPath = "/5r1zWuzbsVAYSPzvCecAReGhN7k.jpg",
        backdropPath = "/yHB0eNR8rvCpn0VdghEwBsXAC0N.jpg",
        vote = 7.7,
        actors = listOf(
            16828,
            1245,
            60898,
            53650,
            71189,
            39459,
            4135,
            2231,
            550843
        )
    ),
    Movie(
        id = 271110,
        genres = listOf(
            "Adventure",
            "Action",
            "Science Fiction"
        ),
        title = "Captain America: Civil War",
        releaseDate = "2016-04-27",
        overview = "Following the events of Age of Ultron, the collective governments of the world pass an act designed to regulate all superhuman activity. This polarizes opinion amongst the Avengers, causing two factions to side with Iron Man or Captain America, which causes an epic battle between former allies.",
        tagline = "Divided We Fall",
        posterPath = "/rAGiXaUfPzY7CDEyNKUofk3Kw2e.jpg",
        backdropPath = "/kvRT3GwcnqGHzPjXIVrVPhUix7Z.jpg",
        vote = 7.4,
        actors = listOf(
            16828,
            3223,
            1245,
            60898,
            53650,
            1896,
            17604,
            172069,
            550843,
            22226,
            1136406,
            227,
            3141,
            21134
        )
    ),
    Movie(
        id = 24428,
        genres = listOf(
            "Science Fiction",
            "Action",
            "Adventure"
        ),
        title = "The Avengers",
        releaseDate = "2012-04-25",
        overview = "When an unexpected enemy emerges and threatens global safety and security, Nick Fury, director of the international peacekeeping agency known as S.H.I.E.L.D., finds himself in need of a team to pull the world back from the brink of disaster. Spanning the globe, a daring recruitment effort begins!",
        tagline = "Some assembly required.",
        posterPath = "/RYMX2wcKCBAr24UyPD7xwmjaTn.jpg",
        backdropPath = "/nNmJRkg8wWnRmzQDe2FwKbPIsJV.jpg",
        vote = 7.7,
        actors = listOf(
            3223,
            16828,
            103,
            74568,
            1245,
            17604,
            91606,
            2231,
            71189,
            12052
        )
    ),
    Movie(
        id = 99861,
        genres = listOf(
            "Action",
            "Adventure",
            "Science Fiction"
        ),
        title = "Avengers: Age of Ultron",
        releaseDate = "2015-04-22",
        overview = "When Tony Stark tries to jumpstart a dormant peacekeeping program, things go awry and Earth’s Mightiest Heroes are put to the ultimate test as the fate of the planet hangs in the balance. As the villainous Ultron emerges, it is up to The Avengers to stop him from enacting his terrible plans, and soon uneasy alliances and unexpected action pave the way for an epic and unique global adventure.",
        tagline = "A New Age Has Come.",
        posterPath = "/4ssDuvEDkSArWEdyBl2X5EHvYKU.jpg",
        backdropPath = "/xnqust9Li4oxfhXD5kcPi3UC8i4.jpg",
        vote = 7.3,
        actors = listOf(
            3223,
            74568,
            103,
            16828,
            1245,
            17604,
            2231,
            1896,
            550843,
            71189,
            53650,
            39459,
            16851
        )
    ),
    Movie(
        id = 299536,
        genres = listOf(
            "Adventure",
            "Action",
            "Science Fiction"
        ),
        title = "Avengers: Infinity War",
        releaseDate = "2018-04-25",
        overview = "As the Avengers and their allies have continued to protect the world from threats too large for any one hero to handle, a new danger has emerged from the cosmic shadows: Thanos. A despot of intergalactic infamy, his goal is to collect all six Infinity Stones, artifacts of unimaginable power, and use them to inflict his twisted will on all of reality. Everything the Avengers have fought for has led up to this moment - the fate of Earth and existence itself has never been more uncertain.",
        tagline = "An entire universe. Once and for all.",
        posterPath = "/7WsyChQLEftFiDOVTGkv3hFpyyt.jpg",
        backdropPath = "/lmZFxXgJE3vgrciwuDib0N8CfQo.jpg",
        vote = 8.3,
        actors = listOf(
            3223,
            74568,
            16828,
            1245,
            71580,
            1136406,
            172069,
            1896,
            8691,
            543261,
            550843,
            53650,
            60898,
            91606,
            82104,
            30082,
            139820,
            543530,
            12835,
            51329,
            12052,
            16851,
            73457,
            227,
            1083010,
            2231,
            71189,
            103
        )
    ),
    Movie(
        id = 299534,
        genres = listOf(
            "Adventure",
            "Science Fiction",
            "Action"
        ),
        title = "Avengers: Endgame",
        releaseDate = "2019-04-24",
        overview = "After the devastating events of Avengers: Infinity War, the universe is in ruins due to the efforts of the Mad Titan, Thanos. With the help of remaining allies, the Avengers must assemble once more in order to undo Thanos' actions and restore order to the universe once and for all, no matter what consequences may be in store.",
        tagline = "Part of the journey is the end.",
        posterPath = "/ulzhLuWrPK07P1YkdWQLZnQh1JL.jpg",
        backdropPath = "/7RyHsO4yDXtBv1zUU3mTpHeQ0d5.jpg",
        vote = 8.3,
        actors = listOf(
            3223,
            16828,
            103,
            74568,
            1245,
            17604,
            1896,
            22226,
            172069,
            71580,
            60073,
            1136406,
            543261,
            8691,
            19034,
            62561,
            14343,
            550843,
            53650,
            60898,
            91606,
            82104,
            30082,
            139820,
            543530,
            1083010,
            21134,
            3063,
            71189,
            15277,
            39459,
            524,
            3141,
            55934,
            9780,
            3392,
            1160,
            227,
            12835,
            51329,
            4135,
            12052,
            73457,
            2231,
            16851
        )
    ),
    Movie(
        id = 118340,
        genres = listOf(
            "Action",
            "Science Fiction",
            "Adventure"
        ),
        title = "Guardians of the Galaxy",
        releaseDate = "2014-07-30",
        overview = "Light years from Earth, 26 years after being abducted, Peter Quill finds himself the prime target of a manhunt after discovering an orb wanted by Ronan the Accuser.",
        tagline = "All heroes start somewhere.",
        posterPath = "/r7vmZjiyZw9rpJMQJdXpjgiCOk9.jpg",
        backdropPath = "/mZSAu5acXueGC4Z3S5iLSWx8AEp.jpg",
        vote = 7.9,
        actors = listOf(
            73457,
            8691,
            543530,
            12835,
            51329,
            543261,
            16851
        )
    ),
    Movie(
        id = 283995,
        genres = listOf(
            "Adventure",
            "Action",
            "Science Fiction",
            "Comedy"
        ),
        title = "Guardians of the Galaxy Vol. 2",
        releaseDate = "2017-04-19",
        overview = "The Guardians must fight to keep their newfound family together as they unravel the mysteries of Peter Quill's true parentage.",
        tagline = "Obviously.",
        posterPath = "/y4MBh0EjBlMuOzv9axM4qJlmhzz.jpg",
        backdropPath = "/aJn9XeesqsrSLKcHfHP4u5985hn.jpg",
        vote = 7.6,
        actors = listOf(
            73457,
            8691,
            543530,
            12835,
            51329,
            543261,
            139820
        )
    ),
    Movie(
        id = 102899,
        genres = listOf(
            "Science Fiction",
            "Action",
            "Adventure"
        ),
        title = "Ant-Man",
        releaseDate = "2015-07-14",
        overview = "Armed with the astonishing ability to shrink in scale but increase in strength, master thief Scott Lang must embrace his inner-hero and help his mentor, Doctor Hank Pym, protect the secret behind his spectacular Ant-Man suit from a new generation of towering threats. Against seemingly insurmountable obstacles, Pym and Lang must plan and pull off a heist that will save the world.",
        tagline = "Heroes don't get any bigger.",
        posterPath = "/rQRnQfUl3kfp78nCWq8Ks04vnq1.jpg",
        backdropPath = "/7AyEEZVtFjNMCOEoz88pBqiAI8n.jpg",
        vote = 7.1,
        actors = listOf(
            22226,
            3392,
            19034,
            53650,
            39459,
            21134,
            16828,
            60898
        )
    ),
    Movie(
        id = 363088,
        genres = listOf(
            "Action",
            "Adventure",
            "Science Fiction"
        ),
        title = "Ant-Man and the Wasp",
        releaseDate = "2018-07-04",
        overview = "Just when his time under house arrest is about to end, Scott Lang once again puts his freedom at risk to help Hope van Dyne and Dr. Hank Pym dive into the quantum realm and try to accomplish, against time and any chance of success, a very dangerous rescue mission.",
        tagline = "Real heroes. Not actual size.",
        posterPath = "/eivQmS3wqzqnQWILHLc4FsEfcXP.jpg",
        backdropPath = "/xjFgtltOOuBtLdNedQH8M1TTrjc.jpg",
        vote = 7.0,
        actors = listOf(
            22226,
            19034,
            1160,
            3392
        )
    ),
    Movie(
        id = 284052,
        genres = listOf(
            "Action",
            "Adventure",
            "Fantasy",
            "Science Fiction"
        ),
        title = "Doctor Strange",
        releaseDate = "2016-10-25",
        overview = "After his career is destroyed, a brilliant but arrogant surgeon gets a new lease on life when a sorcerer takes him under her wing and trains him to defend the world against evil.",
        tagline = "Open your mind. Change your reality.",
        posterPath = "/xf8PbyQcR5ucXErmZNzdKR0s8ya.jpg",
        backdropPath = "/aL53oMdZKZRJRH8txH07DLuleF9.jpg",
        vote = 7.4,
        actors = listOf(
            71580,
            30082,
            3063,
            74568
        )
    ),
    Movie(
        id = 315635,
        genres = listOf(
            "Action",
            "Adventure",
            "Science Fiction",
            "Drama"
        ),
        title = "Spider-Man: Homecoming",
        releaseDate = "2017-07-05",
        overview = "Following the events of Captain America: Civil War, Peter Parker, with the help of his mentor Tony Stark, tries to balance his life as an ordinary high school student in Queens, New York City, with fighting crime as his superhero alter ego Spider-Man as a new threat, the Vulture, emerges.",
        tagline = "Homework can wait. The city can't.",
        posterPath = "/c24sv2weTHPsmDa7jEMN0m2P3RT.jpg",
        backdropPath = "/tTlAA0REGPXSZPBfWyTW9ipIv1I.jpg",
        vote = 7.4,
        actors = listOf(
            1136406,
            3223,
            3141,
            15277,
            12052,
            16828
        )
    ),
    Movie(
        id = 429617,
        genres = listOf(
            "Action",
            "Adventure",
            "Science Fiction"
        ),
        title = "Spider-Man: Far from Home",
        releaseDate = "2019-06-28",
        overview = "Peter Parker and his friends go on a summer trip to Europe. However, they will hardly be able to rest - Peter will have to agree to help Nick Fury uncover the mystery of creatures that cause natural disasters and destruction throughout the continent.",
        tagline = "It’s time to step up.",
        posterPath = "/4q2NNj4S5dG2RLF9CpXsej7yXl.jpg",
        backdropPath = "/8XiTPU1zfy41Xgg96TCHXj4uQJf.jpg",
        vote = 7.5,
        actors = listOf(
            1136406,
            2231,
            3141,
            15277,
            71189
        )
    ),
    Movie(
        id = 284054,
        genres = listOf(
            "Action",
            "Adventure",
            "Science Fiction"
        ),
        title = "Black Panther",
        releaseDate = "2018-02-13",
        overview = "King T'Challa returns home to the reclusive, technologically advanced African nation of Wakanda to serve as his country's new leader. However, T'Challa soon finds that he is challenged for the throne by factions within his own country as well as without. Using powers reserved to Wakandan kings, T'Challa assumes the Black Panther mantle to join with ex-girlfriend Nakia, the queen-mother, his princess-kid sister, members of the Dora Milaje (the Wakandan 'special forces') and an American secret agent, to prevent Wakanda from being dragged into a world war.",
        tagline = "Long live the king.",
        posterPath = "/uxzzxijgPIY7slzFvMotPv8wjKA.jpg",
        backdropPath = "/AlFqBwJnokrp9zWTXOUv7uhkaeq.jpg",
        vote = 7.4,
        actors = listOf(
            172069,
            82104,
            1083010,
            9780,
            60898
        )
    ),
    Movie(
        id = 299537,
        genres = listOf(
            "Action",
            "Adventure",
            "Science Fiction"
        ),
        title = "Captain Marvel",
        releaseDate = "2019-03-06",
        overview = "The story follows Carol Danvers as she becomes one of the universe’s most powerful heroes when Earth is caught in the middle of a galactic war between two alien races. Set in the 1990s, Captain Marvel is an all-new adventure from a previously unseen period in the history of the Marvel Cinematic Universe.",
        tagline = "Higher. Further. Faster.",
        posterPath = "/AtsgWhDnHTq68L0lLsUrCnM7TjG.jpg",
        backdropPath = "/w2PMyoyLU22YvrGK3smVM9fW1jj.jpg",
        vote = 7.0,
        actors = listOf(
            60073,
            2231,
            16828,
            1245,
            1896,
            103
        )
    )
)
